package net.lawaxi.mc.bridgepractice.utils;

public class particles {

}
